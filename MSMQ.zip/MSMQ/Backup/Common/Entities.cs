﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Common
{
    [DataContract]
    public class PurchaseOrder
    {
        [DataMember]
        public string CustomerId { get; set; }

        [DataMember]
        public Guid PONumber { get; set; }

        [DataMember]
        public Category Category { get; set; }

        [DataMember]
        public decimal Total { get; set; }
    }

    [DataContract]
    public enum Category
    {
        [EnumMember]
        None,
        [EnumMember]
        Sofware,
        [EnumMember]
        Hardware,
        [EnumMember]
        Others
    }

    [ServiceContract]
    public interface IOrderProcessorService
    {
        [OperationContract(IsOneWay = true)]
        void SubmitPurchaseOrder(PurchaseOrder msg);
    }

    [ServiceContract]
    public interface IRegisterClientService
    {
        [OperationContract(IsOneWay = true)]
        void RegisterClient(ClientInfo clientInfo);
    }

    [DataContract]
    public class ClientInfo
    {
        [DataMember]
        public string GroupName { get; set; }

        [DataMember]
        public string ClientName { get; set; }

        [DataMember]
        public string PushMessageBoxAddress { get; set; }
    }
}
