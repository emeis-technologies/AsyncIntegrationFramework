﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using System.ServiceModel;
using System.Configuration;
using System.Messaging;
using System.Transactions;

namespace Listener
{
    class Program
    {
        static void Main(string[] args)
        {
            PushMessageService pushMessageService = null;
            ServiceHost pushMessageServiceHost = null;

            string messageBoxMSMQName = ConfigurationManager.AppSettings["MessageBoxMSMQName"];

            if (!MessageQueue.Exists(messageBoxMSMQName))
            {
                MessageQueue versionManagerQueue = MessageQueue.Create(messageBoxMSMQName, true);
                versionManagerQueue.SetPermissions(@"Everyone", MessageQueueAccessRights.FullControl);

                versionManagerQueue.SetPermissions(@"ANONYMOUS LOGON",
                    MessageQueueAccessRights.ReceiveMessage |
                    MessageQueueAccessRights.PeekMessage |
                    MessageQueueAccessRights.WriteMessage);
            }

            pushMessageService = new PushMessageService();
            pushMessageServiceHost = new ServiceHost(pushMessageService);

            pushMessageServiceHost.Open();

            RegisterClientServiceClient registerClientServiceClient
                = new RegisterClientServiceClient("RegisterClientEndPoint");

            using (TransactionScope scope
                = new TransactionScope(TransactionScopeOption.Required))
            {
                ClientInfo clientInfo = new ClientInfo();

                clientInfo.GroupName = ConfigurationManager.AppSettings["GroupName"];
                clientInfo.ClientName = System.Net.Dns.GetHostName();

                clientInfo.PushMessageBoxAddress = "net.msmq://"
                    + clientInfo.ClientName + "/private/WcfServerPush/ClientMessageBox";

                registerClientServiceClient.RegisterClient(clientInfo);

                scope.Complete();
            }

            Console.WriteLine("ServeClientr Started");
            Console.ReadKey();

            registerClientServiceClient.Close();
        }
    }

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class PushMessageService : IOrderProcessorService
    {
        public PushMessageService()
        {
        }

        public void SubmitPurchaseOrder(PurchaseOrder msg)
        {
            Console.WriteLine(msg);
        }
    }

    public class RegisterClientServiceClient
        : ClientBase<IRegisterClientService>, IRegisterClientService
    {
        public RegisterClientServiceClient(string endpointConfigurationName)
            : base(endpointConfigurationName)
        {
        }

        public void RegisterClient(ClientInfo clientInfo)
        {
            base.Channel.RegisterClient(clientInfo);
        }
    }
}
